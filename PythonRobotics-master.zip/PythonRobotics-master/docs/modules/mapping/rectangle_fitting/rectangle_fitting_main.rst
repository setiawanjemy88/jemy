Object shape recognition using rectangle fitting
------------------------------------------------

This is an object shape recognition using rectangle fitting.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Mapping/rectangle_fitting/animation.gif


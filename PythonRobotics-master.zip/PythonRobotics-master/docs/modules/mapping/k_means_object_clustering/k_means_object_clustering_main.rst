k-means object clustering
-------------------------

This is a 2D object clustering with k-means algorithm.

.. image:: https://github.com/AtsushiSakai/PythonRoboticsGifs/raw/master/Mapping/kmeans_clustering/animation.gif
